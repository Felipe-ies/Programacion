/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ivanaliens;

/**
 *
 * @author dam
 */
public class Extraterrestres {
 private String nombre;
private int piernas;
private int cabezas;
private int ojos;
private String  colores;


    public Extraterrestres(String nombre, int piernas, int cabezas , int ojos , String colores) {
        this.nombre = nombre;
        this.piernas = piernas;
        this.cabezas = cabezas;
        this.ojos = ojos;
        this.colores =  colores;
       
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPiernas() {
        return piernas;
    }

    public void setPiernas(int piernas) {
        this.piernas = piernas;
    }

    public int getCabezas() {
        return cabezas;
    }

    public void setCabezas(int cabezas) {
        this.cabezas = cabezas;
    }

    public int getOjos() {
        return ojos;
    }

    public void setOjos(int ojos) {
        this.ojos = ojos;
    }

    public String getColores() {
        return colores;
    }

    public void setColores(String colores) {
        this.colores = colores;
    }

    @Override
    public String toString() {
        return "Extraterrestres{" + "nombre=" + nombre + ", piernas=" + piernas + ", cabezas=" + cabezas + ", ojos=" + ojos + ", color=" + colores + '}';
    }
    















}
