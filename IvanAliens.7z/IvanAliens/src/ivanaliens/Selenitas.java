/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ivanaliens;
import java.util.Random;
/**
 *
 * @author dam
 */
public class Selenitas extends Extraterrestres {
private boolean paz = false;
private String [] armas ;
Random ran = new Random();

    public Selenitas(String[] armas, String nombre, int piernas, int cabezas, int ojos, int atrapados, boolean paz ) {
        super("Selenita", 2,1,1,"azul");
         this.paz = paz;
        this.armas = new String[] { "cañon" , "pistola" , "granada"};
        
    }





  
    public boolean isPaz() {
        return paz;
    }

    public void setPaz(boolean paz) {
        this.paz = paz;
    }

    public String[] getArmas() {
        return armas;
    }

    public void setArmas(String[] armas) {
        this.armas = armas;
    }
  

    @Override
    public int getPiernas() {
        return super.getPiernas();  // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
     
    
    
    
    public void dispararArma(){
      int armamento = ran.nextInt(4); 
        if(armamento  == 0){
            System.out.println("BOUMMM");
        } else{
            System.out.println("BZZZ"); 
        }
    }
    public void atacarTerricola (){
        System.out.println("terricola atrapado");
    }
    @o
}
